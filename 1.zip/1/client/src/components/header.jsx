export default function Header() {
    const handleClickButton = () => {
        localStorage.removeItem('id')
        localStorage.removeItem('role')
        location.reload()
    }

    return (
        <div className="header">
            <h4>Нарушениям.Нет</h4>
            <button onClick={handleClickButton}>Выйти</button>
        </div>
    )
}