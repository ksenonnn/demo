import { useEffect, useState } from "react";

export default function Admin() {
    const [data, setData] = useState([])
    const [userList, setUserList] = useState([])
    const [message, setMessage] = useState('')

    useEffect(() => {
        fetch(`http://localhost:8080/admin`)
            .then(data => data.json())
            .then(json => {
                if (json?.message) {
                    setMessage(json?.message)
                } else {
                    setData(json);
                    json.map(card => {
                        fetch(`http://localhost:8080/user/${card.userId}`)
                            .then(user => user.json())
                            .then(userjson => setUserList(prev => [...prev, { cardId: card.id, name: userjson.name }]))
                    })
                }
            })
    }, [])

    const handleClick = (status, id) => {
        fetch('http://localhost:8080/status', {
            method: "PATCH",
            mode: 'cors',
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                status,
                id
            })
        })
            .then(data => data.json())
            .then(json => {
                if (json?.message == "Ошибка при изменении статуса.") {
                    setMessage(json.message)
                } else {
                    setMessage('');
                    setData(() => data.filter(card => card.id != id))
                }
            })
    }

    console.log(userList);

    return (
        <div className="flex-col">
            <h1>Заявления</h1>
            {message && <p>{message}</p>}
            <div className="flex-col">
                {
                    !message &&
                    data.map(card => (
                        <div className="card cardAdmin">
                            <div className="">
                                <p>Гос. номер автомобиля: {card.numCar}</p>
                                <p>Описание: {card.text}</p>
                                <p>Имя пользователя: {userList.find(user => user.cardId == card.id)?.name}</p>
                            </div>
                            <div className="buttons">
                                <button onClick={() => handleClick(3, card.id)}
                                    style={{
                                        backgroundColor: 'green'
                                    }}
                                >принять</button>
                                <button onClick={() => handleClick(2, card.id)}
                                    style={{
                                        backgroundColor: 'red'
                                    }}
                                >отклонить</button>
                            </div>
                        </div>
                    ))
                }
            </div>
        </div>
    )
}