import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Registration() {
    const [name, setName] = useState('')
    const [phone, setPhone] = useState('')
    const [email, setEmail] = useState('')
    const [login, setLogin] = useState('')
    const [password, setPassword] = useState('')
    const [errors, setErrors] = useState({})
    const [error, setError] = useState('')

    const navigate = useNavigate()

    const handleName = (e) => {
        const input = e.target.value
        const cleanedName = input.replace(/[^a-zA-Zа-яА-ЯёЁ -]/g, '')
        setName(cleanedName)
    };

    const formatPhoneNumber = (input) => {
        const numbers = input.replace(/\D/g, '');

        let formatted = '+7';
        if (numbers.length > 1) {
            formatted += `(${numbers.slice(1, 4)}`;
        }
        if (numbers.length > 4) {
            formatted += `)-${numbers.slice(4, 7)}`;
        }
        if (numbers.length > 7) {
            formatted += `-${numbers.slice(7, 9)}`;
        }
        if (numbers.length > 9) {
            formatted += `-${numbers.slice(9, 11)}`;
        }

        return formatted;
    };

    const handleChangePhone = (e) => {
        const formatted = formatPhoneNumber(e.target.value);
        setPhone(formatted)
        if (e.target.value.replace(/[^0-9+]/g, '').split('').length <= 11) {
            setErrors(prev => ({ ...prev, phone: true }))
        } else {
            setErrors(prev => ({ ...prev, phone: false }))
        }
    };

    const handleEmail = (e) => {
        const input = e.target.value
        setEmail(input)
        const clean = /^[^\s@]+@[^\s@]+.[^\s@]+$/
        const isCleaned = clean.test(input)
        setErrors((prev) => ({ ...prev, email: !isCleaned }))
    }

    const hadleChangePassword = (e) => {
        const input = e.target.value
        setPassword(input)
        if (input.split('').length < 6) {
            setErrors(prev => ({ ...prev, password: true }))
        } else {
            setErrors(prev => ({ ...prev, password: false }))
        }
    }

    const handleClickReg = async () => {
        fetch('http://localhost:8080/reg', {
            method: "POST",
            mode: 'cors',
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                name,
                phone: phone.replace(/[^0-9+]/g, ''),
                email,
                login,
                password
            })
        }).then(data => data.json()).then(json => {
            if (json.message != 'Вы успешно зарегистрированы.') {
                setError(json.message)
            } else {
                alert(json.message);
                navigate('/login')
            }
        })
    }

    return (
        <div className="reg flex-col w-350">
            <h1>Регистрация</h1>
            <div className="flex-col">
                <label>ФИО:</label>
                <input
                    type="text"
                    value={name}
                    onChange={handleName}
                    placeholder="Ваши ФИО"
                    required />
                <label>Номер телефона:</label>
                <input
                    type="tel"
                    value={phone}
                    onChange={handleChangePhone}
                    minLength={17}
                    maxLength={17}
                    placeholder="+7(XXX)-XXX-XX-XX"
                    required />

                {errors.phone && <span>Номер телефона слишком короткий</span>}
                <label>Эл. почта:</label>
                <input
                    type="email"
                    value={email}
                    onChange={handleEmail}
                    placeholder="Эл. почта"
                    required />

                {errors.email && <span>Неверная форма адреса эл. почты</span>}
                <label>Логин:</label>
                <input
                    type="text"
                    value={login}
                    onChange={e => setLogin(e.target.value)}
                    placeholder="Логин"
                    required />
                <label>Пароль:</label>
                <input
                    type="password"
                    value={password}
                    onChange={hadleChangePassword}
                    minLength={6}
                    placeholder="Пароль"
                    required />

                {errors.password && <span>Пароль слишком короткий</span>}
                {error && <span>{error}</span>}
                <button className="btn-reg" onClick={handleClickReg}>Зарегистрироваться</button>
                <p>Ещё нет аккаунта? <Link to={'/login'}>Войти</Link></p>
            </div>
        </div>
    )
}