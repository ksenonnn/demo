import { useState } from "react";
import { Link } from "react-router-dom";

export default function Auth() {
    const [login, setLogin] = useState('')
    const [password, setPassword] = useState('')
    const [error, setError] = useState('')

    const handleClickReg = async () => {
        fetch('http://localhost:8080/auth', {
            method: "POST",
            mode: 'cors',
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                login,
                password
            })
        })
            .then(data => data.json())
            .then(json => {
                if (json?.message) {
                    setError(json.message)
                } else if (json?.user) {
                    setError('')
                    localStorage.setItem("id", json.user.id);
                    localStorage.setItem('role', json.user.roleId);
                    location.reload()
                }
            })
    }

    return (
        <div className="reg flex-col w-350">
            <h1>Вход</h1>
            <div className="flex-col">
                <label>Логин:</label>
                <input
                    type="text"
                    value={login}
                    onChange={e => setLogin(e.target.value)}
                    placeholder="Логин"
                    required />
                <label>Пароль:</label>
                <input
                    type="password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    minLength={6}
                    placeholder="Пароль"
                    required />
                {error && <span>{error}</span>}
                <button className="btn-reg" onClick={handleClickReg}>Войти</button>
                <p>Уже есть аккаунт? <Link to={'/'}>Зарегистрироваться</Link></p>
            </div>
        </div>
    )
}