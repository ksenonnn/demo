import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

export default function Main() {
    const [data, setData] = useState([])
    const [message, setMessage] = useState('')

    const id = localStorage.getItem('id')

    useEffect(() => {
        fetch(`http://localhost:8080/myReq/${id}`)
            .then(data => data.json())
            .then(json => {
                if (json?.message) {
                    setMessage(json?.message)
                } else {
                    setData(json);
                }
            })
    }, [])

    return (
        <div className="flex-col">
            <h1>Мои заявления</h1>
            <Link to={'/new'}>Создать новое</Link>
            {message && <p>{message}</p>}
            <div className="flex-col">
                {
                    !message &&
                    data.map(card => (
                        <div className="card">
                            <p>Гос. номер автомобиля: {card.numCar}</p>
                            <p>Описание: {card.text}</p>
                            <p className="status"
                            style={{
                                backgroundColor: card.statusId == 1 ? 'black' : card.statusId == 2 ? 'red' : 'green'
                            }}>{card.statusId == 1 ? 'новое' : card.statusId == 2 ? 'отклонено' : 'принято'}</p>
                        </div>
                    ))
                }
            </div>
        </div>
    )
}