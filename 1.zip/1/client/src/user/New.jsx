import { useState } from "react";
import { Link } from "react-router-dom";

export default function New() {
    const [numCar, setNumCar] = useState('')
    const [text, setText] = useState([])
    const [message, setMessage] = useState('')

    const id = localStorage.getItem('id')

    const handleClickButton = () => {
        fetch(`http://localhost:8080/newReq/`, {
            method: "POST",
            mode: 'cors',
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                numCar,
                text,
                userId: id
            })
        })
            .then(data => data.json())
            .then(json => {
                if (json?.message == "Заявление успешно отправлено.") {
                    alert(json.message);
                    setNumCar('');
                    setText('')
                } else if (json?.message) {
                    setMessage(json.message)
                }
            })
    }

    return (
        <div className="flex-col w-350">
            <Link to={'/'}>На главную</Link>
            <h1>Новое заявление</h1>
            <div className="flex-col">
                <label>Государственный номер автомобиля:</label>
                <input
                    type="text"
                    value={numCar}
                    onChange={e => setNumCar(e.target.value)}
                    placeholder="Гос. номер"
                    required />
                <label>Описание нарушения:</label>
                <input
                    type="tel"
                    value={text}
                    onChange={e => setText(e.target.value)}
                    placeholder="Описание"
                    required />
                {message && <span>{message}</span>}
                <button onClick={handleClickButton}>Отправить</button>
            </div>
        </div>
    )
}