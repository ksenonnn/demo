import { Navigate, Outlet, RouterProvider, createBrowserRouter } from "react-router-dom"
import Registration from "./Reg"
import Auth from "./Auth"
import Main from "./user/Main"
import New from "./user/New"
import Header from "./components/header"
import Admin from "./admin/Admin"

const router = createBrowserRouter([
  {
    path: '/',
    element: <Registration />
  },
  {
    path: '/login',
    element: <Auth />
  },
  {
    path: "*",
    element: <Navigate to={'/'} />
  }
])

const userRouter = createBrowserRouter([
  {
    path: '/',
    element: <>
      <Header />
      <Outlet />
    </>,
    children: [
      {
        path: '/',
        element: <Main />
      },
      {
        path: '/new',
        element: <New />
      },
    ]
  },
  {
    path: "*",
    element: <Navigate to={'/'} />
  }
])

const adminRouter = createBrowserRouter([
  {
    path: '/',
    element: <>
      <Header />
      <Admin />
    </>
  },
  {
    path: "*",
    element: <Navigate to={'/'} />
  }
])

function App() {
  const id = localStorage.getItem('id')
  const role = localStorage.getItem('role')

  return (
    id ?
      role == 1 ?
        <RouterProvider router={userRouter} /> :
        <RouterProvider router={adminRouter} /> :
      <RouterProvider router={router} />
  )
}

export default App
