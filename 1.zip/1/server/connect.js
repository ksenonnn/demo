import mysql from "mysql2"

export const sql = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '1111',
    database: 'new_schema'
})