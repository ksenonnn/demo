import express from "express"
import cors from "cors"
import { sql } from "./connect.js"

const app = express()

app.use(cors())
app.use(express.json())

// регистрация
app.post('/reg', async (req, res) => {
    const { name, phone, email, login, password } = req.body;

    // Проверка заполненности всех полей
    if (!name || !phone || !email || !login || !password) {
        return res.status(400).send({ message: "Все поля должны быть заполнены." });
    }

    try {
        // Проверка на существующий логин
        const [existingUsers] = await sql.promise().query('SELECT * FROM users WHERE login = ?', [login]);

        if (existingUsers.length > 0) {
            return res.status(400).send({ message: 'Логин уже занят.' });
        }

        // Добавление нового пользователя
        const [result] = await sql.promise().query(
            'INSERT INTO users (name, phone, email, login, password, roleId) VALUES (?, ?, ?, ?, ?, ?)',
            [name, phone, email, login, password, 1]
        );

        console.log(result);

        if (result.affectedRows > 0) {
            res.send({ message: 'Вы успешно зарегистрированы.' });
        } else {
            res.status(404).send({ message: "Произошла ошибка." })
        }
    } catch (err) {
        console.error('Ошибка регистрации:', err);
        res.status(500).send({ message: 'Ошибка регистрации.' });
    }
});

// авторизация
app.post('/auth', async (req, res) => {
    const { login, password } = req.body

    if (!login || !password) return res.status(400).send({ message: "Все поля должны быть заполнены." })

    const [user] = await sql.promise().query(`select * from users where login=?`, [login])

    if (user.length > 0) {
        console.log(user);

        if (user[0].password == password) {
            res.send({ user: user[0] })
        } else {
            res.status(400).send({ message: "Пароль неверный." })
        }
    } else {
        res.status(400).send({ message: "Пользователь не найден." })
    }
})

// заявления определенного пользователя
app.get('/myReq/:id', async (req, res) => {
    const { id } = req.params

    const [requests] = await sql.promise().query(`select * from requests where userId=?`, [id])

    if (requests.length > 0) {
        res.send(requests)
    } else {
        res.send({ message: "Нет заявлений" })
    }
})

// пользователь по ид
app.get('/user/:id', async (req, res) => {
    const { id } = req.params

    const [user] = await sql.promise().query(`select * from users where id=?`, [id])

    if (user.length > 0) {
        res.send(user[0])
    } else {
        res.send({ message: "Пользователь не найден" })
    }
})

// создание нового заявления
app.post('/newReq', async (req, res) => {
    const { numCar, text, userId } = req.body

    if (!numCar || !text || !userId) {
        return res.status(404).send({ message: "Все поля должны быть заполнены." })
    }

    const [request] = await sql.promise().query(`insert into requests (numCar, text, userId, statusId) values (?, ?, ?, ?)`, [numCar, text, userId, 1])

    if (request.affectedRows > 0) {
        return res.send({ message: "Заявление успешно отправлено." })
    }
    else {
        console.log("ОШИБКА newReq:", err);
        return res.status(404).send({ message: "При отправке заявления произошла ошибка." })
    }
})

// изменение статуса заявления
app.patch('/status', async (req, res) => {
    const { status, id } = req.body

    const [request] = await sql.promise().query(`update requests set statusId=? where id=?`, [status, id])

    if (request.affectedRows > 0) {
        return res.send({ message: "Статус обновлен." })
    } else {
        return res.status(404).send({ message: "Ошибка при изменении статуса." })
    }
})

// все новые заявления
app.get('/admin', async (req, res) => {
    const [requests] = await sql.promise().query(`select * from requests where statusId=1`)

    if (requests.length > 0) return res.send(requests)
    else {
        console.log("requests: ", requests);
        return res.send({ message: "Нет новых заявлений" })
    }
})

app.listen(8080, async () => {
    await sql.promise().query(`create table if not exists roles(
        id serial primary key,
        name varchar(45)
    )`);

    await sql.promise().query(`create table if not exists statuses(
        id serial primary key,
        name varchar(45)
    )`);

    await sql.promise().query(`create table if not exists users(
        id serial primary key,
        name varchar(255) not null,
        phone varchar(12) not null,
        email varchar(255) not null,
        login varchar(255) not null,
        password varchar(255) not null,
        roleId bigint unsigned not null,
        foreign key (roleId) references roles(id) 
    )`);

    await sql.promise().query(`create table if not exists requests(
        id serial primary key,
        numCar varchar(9) not null,
        text text not null,
        statusId bigint unsigned not null,
        userId bigint unsigned not null,
        foreign key (statusId) references statuses(id),
        foreign key (userId) references users(id)
    )`);

    // await sql.promise().query(`insert into roles (name) values ('USER'), ('ADMIN')`)
    // await sql.promise().query(`insert into statuses (name) values ('новое'), ('отклонено'), ('принято')`)

    console.log('ACTIVE PORT 8080')
})